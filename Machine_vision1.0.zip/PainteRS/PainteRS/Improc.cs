﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System.Windows;
using System.Windows.Controls;

namespace PainteRS
{
    internal class Improc 
    {
        public List<Point> BP { get; } = new List<Point>(); //массив для чёрных пикселей
        public Point centerMass;
        public Point centerMat;
        double MinMaxOtnoshenie = 0.0; // отношение минимальной длинны (от центра масс до фигуры) к максимальной

        public Improc(FrameworkElement elem) // получает канвас
        {

            // Get the size of canvas
            Size size = new Size(elem.Width, elem.Height);
            // Measure and arrange the surface
            // VERY IMPORTANT
            elem.Measure(size);
            elem.Arrange(new Rect(size));
            

            RenderTargetBitmap bitmap = new RenderTargetBitmap
                ((int)size.Width, (int)size.Height, 96d,96d,
      PixelFormats.Pbgra32); //создаём "катртинку" размерам с нашь canvas
                             //Обязательно использовать Pbrgba32 !!!!!
            elem.Measure(new Size((int)elem.Width, (int)elem.Height));
            elem.Arrange(new Rect(new Size((int)elem.Width, (int)elem.Height)));

            bitmap.Render(elem);//переносим туда наше полотно

            int widthPich = bitmap.PixelWidth;
            int heightPich = bitmap.PixelHeight;
            int[] array = new int[widthPich*4 * heightPich]; // массив для пикселей

            bitmap.CopyPixels(array, widthPich*4, 0); // копирование информации о пикселях в массив

            int x = 0;
            int y = 0;
            List<Color> colors = new List<Color>();
            for (int i = 0; i < array.Length; i++)
            {
                byte[] bytes = BitConverter.GetBytes(array[i]);
                Color pixel = Color.FromArgb(bytes[3], bytes[2], bytes[1], bytes[0]);
                colors.Add(pixel);

                // Сверху информация о пикселах каждого раздельно
            }
                //  Снизу заносятся в массив чёрные пиксели

            for (int i = 0; i < colors.Count; i++)
            {
                if (colors[i].ToString() == "#FF000000")
                {
                    BP.Add(new Point(x, y));
                }
                if (i == widthPich * (y+1) - 1)
                {
                    x = -1;
                    ++y;
                }
                x++;
            }

        }

        public double ProbLit() // Возвращает отношение минимальной длинны (от центра масс до фигуры) к максимальной
        {
            var centerMatMin = BP[0];
            Point centerMatMax = new Point(0, 0);

            foreach(var item in BP) // находит центр масс и математический центр
            {
                centerMass.X += item.X;
                centerMass.Y += item.Y;
                if (item.Y < centerMatMin.Y) centerMatMin.Y = item.Y;
                else if (item.Y > centerMatMax.Y) centerMatMax.Y = item.Y;
                if (item.X < centerMatMin.X) centerMatMin.X = item.X;
                else if (item.X > centerMatMax.X) centerMatMax.X = item.X;
            }

            centerMat = new Point((centerMatMax.X + centerMatMin.X) / 2, 
                                  (centerMatMax.Y + centerMatMin.Y) / 2); // математический центр
            centerMass.X /= BP.Count;
            centerMass.Y /= BP.Count;
            double mindist = 1000.0;
            double maxdist = 0.0;
            double dist;
            foreach (Point item in BP)
            {
                dist = Math.Sqrt(((item.X - centerMass.X) * (item.X - centerMass.X)) 
                               + ((item.Y - centerMass.Y) * (item.Y - centerMass.Y)));
                if (dist > maxdist) { maxdist = dist; }
                if (dist < mindist) { mindist = dist; }
            }
            MinMaxOtnoshenie = mindist / maxdist;
            return MinMaxOtnoshenie;
        }


        public string WhatsLett() // Возвращает цифру которую мы выводим
        {
            if (MinMaxOtnoshenie < 0.2)
            {
                return "1";
            }
            else if (MinMaxOtnoshenie > 0.4)
            {
                return "0";
            }
            else
            {
                return "NULL";
            }
        }
    }
}
